package jp.co.internous.eadylogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EasyloginApplicationTests {

	@Test
	void contextLoads() {
	}

}
